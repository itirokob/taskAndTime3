//
//  WidgetCell.swift
//  gg-lean
//
//  Created by Bianca Yoshie Itiroko on 14/07/17.
//  Copyright © 2017 Bepid. All rights reserved.
//

import Foundation
import UIKit

class WidgetCell:UITableViewCell {
    @IBOutlet weak var taskLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!

}
